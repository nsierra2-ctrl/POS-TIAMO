// src/app/cocina/page.js
"use client";
import { useEffect, useState, useRef } from "react";
import { collection, query, orderBy, onSnapshot, where } from "firebase/firestore";
import { db } from "@/lib/firebase";
import PedidoCard from "@/components/PedidoCard";

export default function CocinaPage() {
  const [pedidos, setPedidos] = useState([]);
  const [loading, setLoading] = useState(true);
  const prevIds = useRef(new Set());
  const audioRef = useRef(null);

  useEffect(() => {
    // Create audio context for alert sound
    audioRef.current = new Audio("/alert.mp3");
    audioRef.current.volume = 0.7;

    const q = query(
      collection(db, "pedidos"),
      where("estado", "in", ["nuevo", "preparando"]),
      orderBy("createdAt", "asc")
    );

    const unsub = onSnapshot(q, (snap) => {
      const data = snap.docs.map((d) => ({ id: d.id, ...d.data() }));

      // Detect new orders
      const currentIds = new Set(data.map((p) => p.id));
      const hasNew = data.some((p) => !prevIds.current.has(p.id));

      if (hasNew && prevIds.current.size > 0) {
        try {
          audioRef.current?.play().catch(() => {});
        } catch (e) {}
      }

      prevIds.current = currentIds;
      setPedidos(data);
      setLoading(false);
    });

    return () => unsub();
  }, []);

  const nuevos = pedidos.filter((p) => p.estado === "nuevo");
  const preparando = pedidos.filter((p) => p.estado === "preparando");

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0D0D0D] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-red-600 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-white/40 font-bold">Conectando con cocina...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0D0D0D] text-white">
      {/* Header */}
      <div className="bg-[#0D0D0D]/95 border-b border-white/5 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-red-600 rounded-xl flex items-center justify-center text-lg font-black">V</div>
          <div>
            <p className="font-black text-xl text-white leading-none">VENTURA OS</p>
            <p className="text-white/30 text-sm">Pantalla de Cocina</p>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <div className="text-center">
            <p className="text-amber-400 font-black text-3xl leading-none">{nuevos.length}</p>
            <p className="text-white/30 text-xs uppercase tracking-widest">Nuevos</p>
          </div>
          <div className="text-center">
            <p className="text-blue-400 font-black text-3xl leading-none">{preparando.length}</p>
            <p className="text-white/30 text-xs uppercase tracking-widest">Preparando</p>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
            <span className="text-emerald-400 text-sm font-bold">EN VIVO</span>
          </div>
        </div>
      </div>

      {/* Content */}
      {pedidos.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-[70vh] gap-4">
          <span className="text-8xl opacity-20">🍕</span>
          <p className="text-white/20 font-bold text-xl">Sin pedidos activos</p>
          <p className="text-white/10 text-sm">Los pedidos aparecerán aquí en tiempo real</p>
        </div>
      ) : (
        <div className="p-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 auto-rows-min">
          {/* New orders first */}
          {nuevos.map((pedido) => (
            <PedidoCard key={pedido.id} pedido={pedido} isNew />
          ))}
          {/* Then preparing */}
          {preparando.map((pedido) => (
            <PedidoCard key={pedido.id} pedido={pedido} />
          ))}
        </div>
      )}

      {/* Footer clock */}
      <div className="fixed bottom-4 right-6 text-white/20 font-mono text-sm">
        <Clock />
      </div>
    </div>
  );
}

function Clock() {
  const [time, setTime] = useState("");
  useEffect(() => {
    const tick = () => setTime(new Date().toLocaleTimeString("es-CO"));
    tick();
    const i = setInterval(tick, 1000);
    return () => clearInterval(i);
  }, []);
  return <span>{time}</span>;
}
