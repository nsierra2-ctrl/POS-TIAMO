# 🍕 VENTURA OS — Sistema POS

Sistema de pedidos profesional para Ventura's Pizza.

## Instalación

```bash
npm install
```

## Configuración Firebase

1. Ve a https://console.firebase.google.com
2. Crea un proyecto nuevo
3. Activa Firestore Database (modo producción)
4. Copia `.env.local.example` → `.env.local`
5. Rellena tus credenciales de Firebase

## Reglas Firestore

En Firebase Console → Firestore → Rules:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /pedidos/{pedidoId} {
      allow read, write: if true; // cambiar por autenticación en producción
    }
  }
}
```

## Ejecutar

```bash
npm run dev
```

## Rutas

- `/` → Pantalla Mesero (mesas + pedidos)
- `/cocina` → Pantalla Cocina (TV)

## Sonido

Coloca un archivo `alert.mp3` en `/public/alert.mp3` para el sonido de nuevos pedidos.
